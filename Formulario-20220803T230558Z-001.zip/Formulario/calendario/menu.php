<nav class="navbar navbar-expand navbar-dark bg-dark mb-5"> <!-- Clases bootstrap -->
    <ul class='navbar-nav'>
        <li class="nav-item">
            <a class="nav-link" href="<?=ROOT?>/Patients/add.php">Registrar sesion</a>
        </li>
        <li class= "nav-item">
            <a class="nav-link" href="<?=ROOT?>/Patients/index.php">Citas</a>
        </li>
    <ul>
</nav>