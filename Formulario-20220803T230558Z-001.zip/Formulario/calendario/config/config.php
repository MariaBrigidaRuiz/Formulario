<?php
include('functions.php'); 
 if(!defined('ROOT'))/**Si no esta definida */ { 
    define('ROOT','http://'.$_SERVER['HTTP_HOST'].getFolderProyect());//Constates 

 }
 /**Ruta del puerto y lugar a ingresar  */
 ?>