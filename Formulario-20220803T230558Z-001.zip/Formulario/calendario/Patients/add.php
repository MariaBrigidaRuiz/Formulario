<?php
    include_once('../config/config.php'); //include Once incluye una sola vez 
    include('users.php'); 

    if (isset($_POST) && !empty($_POST)){ //si existe post
        $p = new  users();
        $save = $p ->save($_POST);
        if($save){
            $mensaje = '<div  class="alert alert-success" role="alert">Sesion resgistrada </div>';
        }else{
            $mensaje = '<div class="alert alert-danger" role="alert">Error al registrar </div>';
        }
 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar sesion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>
<body>
    <?php include('../menu.php')?>
    <div class="container">
        <?php
        if (isset($mensaje)){
            echo $mensaje;
        }
        ?>
        <h2 class="text-center mb-2"> Registrar sesion</h2>
        <form  method="POST" enctype ="multipart/from-data">
   
        <div class="row mb-2">
            <div class="col">
                <input type="text" name="nombres" id="nombres" placeholder="Nombre del usuario" class="form-control"/>
            </div>
            <div class="col">
                <input type="text" name="apellidos" id="apellidos" placeholder="Apellidos del usuario" class="form-control"/>
            </div>
        </div>

    <div class="row mb-2">
        <div class="col">
            <input type="email" name="email" id="email" placeholder="Email del usuario" class="form-control"/>
        </div>
        <div class="col">
            <input type="number" name="celular" id="celular" placeholder="Celular del usuario" class="form-control"/>
        </div>
    </div>

    <div class="row mb-2">
        <div class="col">
            <textarea id="observaciones" name="observaciones" placeholder="Observaciones"
            class="form-control">Observacion </textarea>    
        </div>
        <div class="col">
            <input type="text" name="duracionSesion" id="duracionSesion" placeholder="Duracion de la sesion" 
            class="form-control"/>
        </div>
    </div>

    <div class="row mb-2">
        <div class="col">
            <input type="datetime-local" name="fecha" id="fecha" class="form-control"/>
        </div>
    </div>

    <button class="btn btn-success"> Registrar Informacion</button>
  </form>       
</div>   

    
</body>
</html>